from flask import Flask, render_template, request, redirect, flash, session, url_for, jsonify
from pymongo import MongoClient
from bson import ObjectId
from dotenv import load_dotenv
import os
from flask_bcrypt import Bcrypt
from datetime import datetime, timedelta
import urllib.parse
import certifi
from flask_mail import Mail, Message
import secrets
import re
from markupsafe import Markup
import logging
import boto3

# Add AWS Cognito Configuration after loading environment variables
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
COGNITO_USER_POOL_ID = os.getenv('COGNITO_USER_POOL_ID')
COGNITO_CLIENT_ID = os.getenv('COGNITO_CLIENT_ID')

cognito_client = boto3.client('cognito-idp', region_name=AWS_REGION)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'hyrup_secret'
bcrypt = Bcrypt(app)

# Load environment variables from .env file
load_dotenv()

# Define pluralize filter for Jinja2
def pluralize(count):
    return 's' if count != 1 else ''

app.jinja_env.filters['pluralize'] = pluralize

# Configure Flask-Mail for email functionality (used in forgot password)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_USERNAME')

mail = Mail(app)


# Initialize MongoDB client
client = None
db = None
try:
    client = MongoClient(mongo_uri, tlsCAFile=certifi.where(), serverSelectionTimeoutMS=5000)
    client.server_info()  # Test connection
    db = client[mongo_dbname]
    logger.info("MongoDB Atlas connected successfully")
except Exception as e:
    logger.error(f"MongoDB Atlas connection failed: {e}")
    db = None

# nl2br filter for Jinja2
def nl2br(value):
    return Markup(value.replace('\n', '<br>'))
app.jinja_env.filters['nl2br'] = nl2br

# Custom filter to strip URLs from text
def strip_urls(value):
    if not value:
        return value
    url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    return re.sub(url_pattern, '', value).strip()
app.jinja_env.filters['strip_urls'] = strip_urls

# Helper function to validate experience level
def validate_experience_level(level):
    try:
        level = int(level)
        return 1 <= level <= 5
    except (ValueError, TypeError):
        return False

# Helper function to convert string experience level to integer
def map_experience_level(level):
    experience_level_map = {
        "Entry-Level": 1,
        "Mid-Level": 3,
        "Senior": 5
    }
    if isinstance(level, str):
        return experience_level_map.get(level, 1)  # Default to 1 if unknown
    return int(level) if isinstance(level, (int, str)) and validate_experience_level(level) else 1

# Helper function to get unread notifications count
def get_unread_notifications_count(user_id):
    if db is None:
        return 0
    notifications_collection = db['notifications']
    count = notifications_collection.count_documents({
        'user_id': ObjectId(user_id),
        'read': False
    })
    return count

# Home route
@app.route('/')
def home():
    unread_notifications = 0
    if 'user_id' in session:
        unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('hyrup.html', unread_notifications=unread_notifications)

# Sign Up route
# Replace the existing /register_job_seekers route with this
@app.route('/register_job_seekers', methods=['GET', 'POST'])
def register_job_seekers():
    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('signup.html', form_data={}, errors={})

    users_collection = db['users']

    education_levels = [
        {'value': 'high_school', 'label': 'High School'},
        {'value': 'bachelor', 'label': "Bachelor's Degree"},
        {'value': 'master', 'label': "Master's Degree"},
        {'value': 'phd', 'label': 'PhD'}
    ]
    job_types = [
        {'value': 'full-time', 'label': 'Full-time'},
        {'value': 'part-time', 'label': 'Part-time'},
        {'value': 'contract', 'label': 'Contract'},
        {'value': 'internship', 'label': 'Internship'},
        {'value': 'remote', 'label': 'Remote'}
    ]
    roles = [
        {'value': 'job_seeker', 'label': 'Job Seeker'},
        {'value': 'job_poster', 'label': 'Job Poster'},
        {'value': 'mentor', 'label': 'Mentor'}
    ]

    if request.method == 'POST':
        form_data = {
            'Name': request.form.get('Name', ''),
            'Email': request.form.get('Email', ''),
            'Skills': request.form.get('Skills', ''),
            'Education_level': request.form.get('Education_level', ''),
            'Job_type': request.form.get('Job_type', ''),
            'Resume': request.form.get('Resume', ''),
            'Experience_levelID': request.form.get('Experience_levelID', ''),
            'Specialization': request.form.get('Specialization', ''),
            'Role': request.form.get('Role', ''),
            'Company_name': request.form.get('Company_name', '') if request.form.get('Role') == 'job_poster' else ''
        }
        password = request.form.get('password', '')
        errors = {}

        # Validate common mandatory fields
        if not form_data['Name']:
            errors['Name'] = 'Full name is required'
        if not form_data['Email']:
            errors['Email'] = 'Email is required'
        else:
            email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_pattern.match(form_data['Email']):
                errors['Email'] = 'Invalid email format'
        if not password:
            errors['password'] = 'Password is required'
        if not form_data['Role']:
            errors['Role'] = 'Role is required'

        # Role-specific validations
        if form_data['Role'] == 'job_seeker':
            if not form_data['Job_type']:
                errors['Job_type'] = 'Preferred job type is required for job seekers'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for job seekers'
        elif form_data['Role'] == 'job_poster':
            if not form_data['Company_name']:
                errors['Company_name'] = 'Company name is required for job posters'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for job posters'
        elif form_data['Role'] == 'mentor':
            if not form_data['Specialization']:
                errors['Specialization'] = 'Specialization is required for mentors'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for mentors'

        # Validate experience level
        if form_data['Experience_levelID']:
            if not validate_experience_level(form_data['Experience_levelID']):
                errors['Experience_levelID'] = 'Experience level must be between 1 and 5'
            else:
                form_data['Experience_levelID'] = int(form_data['Experience_levelID'])

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)

        # Check if email already exists in Cognito
        try:
            cognito_client.admin_get_user(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=form_data['Email'].lower()
            )
            errors['Email'] = 'Email already registered'
            flash('Email already registered!', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)
        except cognito_client.exceptions.UserNotFoundException:
            pass  # Email not registered, proceed with signup
        except Exception as e:
            logger.error(f"Error checking Cognito user: {e}")
            flash('An error occurred. Please try again later.', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)

        # Register user in Cognito
        try:
            response = cognito_client.sign_up(
                ClientId=COGNITO_CLIENT_ID,
                Username=form_data['Email'].lower(),
                Password=password,
                UserAttributes=[
                    {'Name': 'name', 'Value': form_data['Name']},
                    {'Name': 'email', 'Value': form_data['Email'].lower()},
                    {'Name': 'custom:role', 'Value': form_data['Role']},
                    {'Name': 'custom:skills', 'Value': form_data['Skills'] or ''},
                    {'Name': 'custom:education_level', 'Value': form_data['Education_level'] or ''},
                    {'Name': 'custom:job_type', 'Value': form_data['Job_type'] or ''},
                    {'Name': 'custom:resume', 'Value': form_data['Resume']},
                    {'Name': 'custom:experience_level', 'Value': str(form_data['Experience_levelID']) if form_data['Experience_levelID'] else ''},
                    {'Name': 'custom:specialization', 'Value': form_data['Specialization'] or ''},
                    {'Name': 'custom:company_name', 'Value': form_data['Company_name'] or ''}
                ]
            )
            logger.info(f"Cognito signup successful for {form_data['Email']}")
        except cognito_client.exceptions.UsernameExistsException:
            errors['Email'] = 'Email already registered'
            flash('Email already registered!', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)
        except cognito_client.exceptions.InvalidPasswordException:
            errors['password'] = 'Password does not meet requirements'
            flash('Password does not meet requirements. It must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)
        except Exception as e:
            logger.error(f"Cognito signup error: {e}")
            flash('An error occurred during signup. Please try again.', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)

        # Store user in MongoDB
        user = {
            'cognito_user_id': response['UserSub'],  # Store Cognito Sub ID
            'name': form_data['Name'],
            'email': form_data['Email'].lower(),
            'role': form_data['Role'],
            'skills': form_data['Skills'] or None,
            'education_level': form_data['Education_level'] or None,
            'job_type': form_data['Job_type'] or None,
            'resume': form_data['Resume'],
            'experience_level': form_data['Experience_levelID'] if form_data['Experience_levelID'] else None,
            'specialization': form_data['Specialization'] or None,
            'company_name': form_data['Company_name'] if form_data['Role'] == 'job_poster' else None,
            'created_at': datetime.utcnow(),
            'saved_jobs': [] if form_data['Role'] == 'job_seeker' else []
        }

        try:
            users_collection.insert_one(user)
            logger.info(f"User {form_data['Email']} stored in MongoDB")
        except Exception as e:
            logger.error(f"MongoDB insert error: {e}")
            # Optional: Delete Cognito user if MongoDB insert fails
            try:
                cognito_client.admin_delete_user(
                    UserPoolId=COGNITO_USER_POOL_ID,
                    Username=form_data['Email'].lower()
                )
            except Exception as delete_error:
                logger.error(f"Failed to delete Cognito user after MongoDB error: {delete_error}")
            flash('An error occurred while saving user data. Please try again.', 'error')
            return render_template('signup.html', form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles)

        flash('Registration successful! Please check your email to verify your account.', 'success')
        return redirect(url_for('verify_email', email=form_data['Email'].lower()))

    return render_template('signup.html', form_data={}, errors={},
                         education_levels=education_levels, job_types=job_types, roles=roles)

# Add this new route for email verification
@app.route('/verify_email/<email>', methods=['GET', 'POST'])
def verify_email(email):
    if request.method == 'POST':
        verification_code = request.form.get('verification_code', '').strip()
        errors = {}

        if not verification_code:
            errors['verification_code'] = 'Verification code is required'

        if errors:
            flash('Please enter a verification code.', 'error')
            return render_template('verify_email.html', email=email, errors=errors)

        try:
            cognito_client.confirm_sign_up(
                ClientId=COGNITO_CLIENT_ID,
                Username=email,
                ConfirmationCode=verification_code
            )
            flash('Email verified successfully! Please sign in.', 'success')
            return redirect(url_for('signin'))
        except cognito_client.exceptions.CodeMismatchException:
            errors['verification_code'] = 'Invalid verification code'
            flash('Invalid verification code.', 'error')
        except cognito_client.exceptions.ExpiredCodeException:
            errors['verification_code'] = 'Verification code has expired'
            flash('Verification code has expired. Please request a new one.', 'error')
        except Exception as e:
            logger.error(f"Verification error: {e}")
            flash('An error occurred during verification. Please try again.', 'error')

        return render_template('verify_email.html', email=email, errors=errors)

    return render_template('verify_email.html', email=email, errors={})

# Mentor route
@app.route('/mentor', methods=['GET', 'POST'])
def mentor():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') not in ['job_seeker', 'job_poster', 'mentor']:
        flash('You do not have permission to access this page.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('mentor.html', contacts=[], conversations=[], selected_contact=None, messages=[], unread_notifications=0, is_mentor=False)

    users_collection = db['users']
    messages_collection = db['messages']
    notifications_collection = db['notifications']

    current_user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    is_mentor = current_user['role'] == 'mentor'

    # Fetch contacts
    contacts = []
    if is_mentor:
        received_messages = messages_collection.distinct('sender_id', {'receiver_id': ObjectId(session['user_id'])})
        for user_id in received_messages:
            user = users_collection.find_one({'_id': user_id})
            if user:
                contacts.append({
                    'id': str(user['_id']),
                    'name': user['name'],
                    'specialization': user.get('role', 'User')
                })
    else:
        mentors = users_collection.find({'role': 'mentor', '_id': {'$ne': ObjectId(session['user_id'])}})
        contacts = [
            {'id': str(mentor['_id']), 'name': mentor['name'], 'specialization': mentor.get('specialization', 'Not specified')}
            for mentor in mentors
        ]

    # Fetch conversations
    conversations = []
    conversation_ids = messages_collection.distinct(
        'conversation_id',
        {'$or': [{'sender_id': ObjectId(session['user_id'])}, {'receiver_id': ObjectId(session['user_id'])}]}
    )
    for convo_id in conversation_ids:
        last_message = messages_collection.find_one(
            {'conversation_id': convo_id},
            sort=[('timestamp', -1)]
        )
        if last_message:
            other_user_id = last_message['receiver_id'] if last_message['sender_id'] == ObjectId(session['user_id']) else last_message['sender_id']
            other_user = users_collection.find_one({'_id': other_user_id})
            if other_user:
                role_detail = other_user.get('specialization', 'Not specified') if other_user['role'] == 'mentor' else \
                              other_user.get('skills', 'Not specified') if other_user['role'] == 'job_seeker' else \
                              other_user.get('job_type', 'Not specified')
                conversations.append({
                    'id': str(other_user['_id']),
                    'name': other_user['name'],
                    'role': other_user['role'],
                    'role_detail': role_detail,
                    'message_snippet': last_message['message'][:50] + '...' if len(last_message['message']) > 50 else last_message['message'],
                    'timestamp': last_message['timestamp']
                })

    # Sort conversations by timestamp
    conversations.sort(key=lambda x: x['timestamp'] if x['timestamp'] else datetime.min, reverse=True)

    # Handle selected contact and messages
    selected_contact = None
    messages = []
    selected_contact_id = request.args.get('contact_id') or (request.form.get('contact_id') if request.method == 'POST' else None)
    if selected_contact_id:
        selected_contact = users_collection.find_one({'_id': ObjectId(selected_contact_id)})
        if selected_contact:
            role_detail = selected_contact.get('specialization', 'Not specified') if selected_contact['role'] == 'mentor' else \
                          selected_contact.get('skills', 'Not specified') if selected_contact['role'] == 'job_seeker' else \
                          selected_contact.get('job_type', 'Not specified')
            selected_contact = {
                'id': str(selected_contact['_id']),
                'name': selected_contact['name'],
                'specialization': role_detail
            }

            messages = messages_collection.find({
                '$or': [
                    {'sender_id': ObjectId(session['user_id']), 'receiver_id': ObjectId(selected_contact_id)},
                    {'sender_id': ObjectId(selected_contact_id), 'receiver_id': ObjectId(session['user_id'])}
                ]
            }).sort('timestamp', 1)
            messages = [
                {
                    'sender_id': str(message['sender_id']),
                    'message': message['message'],
                    'timestamp': message['timestamp']
                }
                for message in messages
            ]

    # Handle new message submission
    if request.method == 'POST' and selected_contact_id:
        message_content = request.form.get('message', '').strip()
        if message_content:
            message = {
                'conversation_id': f"{min(session['user_id'], selected_contact_id)}_{max(session['user_id'], selected_contact_id)}",
                'sender_id': ObjectId(session['user_id']),
                'receiver_id': ObjectId(selected_contact_id),
                'message': message_content,
                'timestamp': datetime.utcnow()
            }
            messages_collection.insert_one(message)

            receiver = users_collection.find_one({'_id': ObjectId(selected_contact_id)})
            sender_name = current_user['name']
            notification_message = f"You have a new message from {sender_name}."
            notifications_collection.insert_one({
                'user_id': ObjectId(selected_contact_id),
                'type': 'new_message',
                'message': notification_message,
                'contact_id': session['user_id'],
                'read': False,
                'created_at': datetime.utcnow()
            })

            return redirect(url_for('mentor', contact_id=selected_contact_id))

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('mentor.html', contacts=contacts, conversations=conversations, selected_contact=selected_contact, 
                          messages=messages, unread_notifications=unread_notifications, is_mentor=is_mentor)

# AJAX endpoint to fetch new messages
@app.route('/get_messages/<contact_id>')
def get_messages(contact_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'}), 401

    if session.get('user_role') not in ['job_seeker', 'job_poster', 'mentor']:
        return jsonify({'success': False, 'message': 'You do not have permission to access this endpoint.'}), 403

    if db is None:
        return jsonify({'success': False, 'message': 'Database connection failed'}), 500

    messages_collection = db['messages']
    try:
        messages = messages_collection.find({
            '$or': [
                {'sender_id': ObjectId(session['user_id']), 'receiver_id': ObjectId(contact_id)},
                {'sender_id': ObjectId(contact_id), 'receiver_id': ObjectId(session['user_id'])}
            ]
        }).sort('timestamp', 1)
        messages_list = [
            {
                'sender_id': str(message['sender_id']),
                'message': message['message'],
                'timestamp': message['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
            }
            for message in messages
        ]
        return jsonify({'success': True, 'messages': messages_list})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Sign In route
@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if db is None:
        logger.error("Database connection failed")
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('signin.html', form_data={}, errors={})

    users_collection = db['users']

    if request.method == 'POST':
        form_data = {'email': request.form.get('email', '').strip().lower()}
        password = request.form.get('password', '')
        errors = {}

        # Validate inputs
        if not form_data['email']:
            errors['email'] = 'Email is required'
        else:
            email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_pattern.match(form_data['email']):
                errors['email'] = 'Invalid email format'
        if not password:
            errors['password'] = 'Password is required'

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('signin.html', form_data=form_data, errors=errors)

        logger.debug(f"Attempting login for email: {form_data['email']}")
        try:
            # Authenticate with Cognito
            response = cognito_client.initiate_auth(
                ClientId=COGNITO_CLIENT_ID,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': form_data['email'],
                    'PASSWORD': password
                }
            )
            logger.info(f"Cognito authentication successful for {form_data['email']}")

            # Check user status
            user_status = cognito_client.admin_get_user(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=form_data['email']
            )
            if user_status['UserStatus'] != 'CONFIRMED':
                flash('Please verify your email before signing in.', 'error')
                return render_template('signin.html', form_data=form_data, errors=errors)

            # Fetch user from MongoDB
            user = users_collection.find_one({'email': form_data['email']})
            if not user:
                logger.error(f"User not found in MongoDB for email: {form_data['email']}")
                flash('User data not found. Please contact support.', 'error')
                return render_template('signin.html', form_data=form_data, errors=errors)

            # Store user details in session
            session['user_id'] = str(user['_id'])
            session['user_name'] = user['name']
            session['user_role'] = user['role']
            logger.info(f"Login successful for {form_data['email']}")
            flash('Login successful!', 'success')
            return redirect(url_for('explore'))

        except cognito_client.exceptions.NotAuthorizedException:
            logger.debug(f"Authentication failed for {form_data['email']}")
            errors['email'] = 'Invalid email or password'
            flash('Invalid email or password', 'error')
        except cognito_client.exceptions.UserNotConfirmedException:
            logger.debug(f"User not confirmed for {form_data['email']}")
            flash('Please verify your email before signing in.', 'error')
            return redirect(url_for('verify_email', email=form_data['email']))
        except cognito_client.exceptions.UserNotFoundException:
            logger.debug(f"No user found in Cognito for email: {form_data['email']}")
            errors['email'] = 'Invalid email or password'
            flash('Invalid email or password', 'error')
        except Exception as e:
            logger.error(f"Sign-in error for {form_data['email']}: {e}")
            flash('An error occurred during sign-in. Please try again.', 'error')

        return render_template('signin.html', form_data=form_data, errors=errors)

    return render_template('signin.html', form_data={}, errors={})
# Forgot Password route
# Forgot Password route
@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        errors = {}

        if not email:
            errors['email'] = 'Email is required'
        else:
            email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_pattern.match(email):
                errors['email'] = 'Invalid email format'

        if errors:
            flash('Please correct the errors in the form.', 'error')
            return render_template('forgot_password.html', form_data={'email': email}, errors=errors)

        try:
            # Initiate forgot password with Cognito
            cognito_client.forgot_password(
                ClientId=COGNITO_CLIENT_ID,
                Username=email
            )
            logger.info(f"Password reset initiated for {email}")
            flash('A password reset code has been sent to your email.', 'success')
            return redirect(url_for('reset_password', email=email))

        except cognito_client.exceptions.UserNotFoundException:
            errors['email'] = 'No user found with this email'
            flash('No user found with this email', 'error')
        except cognito_client.exceptions.UserNotConfirmedException:
            errors['email'] = 'Please verify your email before resetting your password'
            flash('Please verify your email before resetting your password', 'error')
        except Exception as e:
            logger.error(f"Failed to initiate password reset: {e}")
            flash('Failed to send reset code. Please try again later.', 'error')

        return render_template('forgot_password.html', form_data={'email': email}, errors=errors)

    return render_template('forgot_password.html', form_data={'email': ''}, errors={})

# Reset Password route
@app.route('/reset_password/<email>', methods=['GET', 'POST'])
def reset_password(email):
    if request.method == 'POST':
        verification_code = request.form.get('verification_code', '').strip()
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')
        errors = {}

        if not verification_code:
            errors['verification_code'] = 'Verification code is required'
        if not new_password:
            errors['new_password'] = 'New password is required'
        if not confirm_password:
            errors['confirm_password'] = 'Confirm password is required'
        if new_password and confirm_password and new_password != confirm_password:
            errors['confirm_password'] = 'Passwords do not match'

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('reset_password.html', email=email, errors=errors)

        try:
            # Confirm password reset with Cognito
            cognito_client.confirm_forgot_password(
                ClientId=COGNITO_CLIENT_ID,
                Username=email.lower(),
                ConfirmationCode=verification_code,
                Password=new_password
            )
            logger.info(f"Password reset successful for {email}")
            flash('Password reset successfully! Please sign in with your new password.', 'success')
            return redirect(url_for('signin'))

        except cognito_client.exceptions.CodeMismatchException:
            errors['verification_code'] = 'Invalid verification code'
            flash('Invalid verification code.', 'error')
        except cognito_client.exceptions.ExpiredCodeException:
            errors['verification_code'] = 'Verification code has expired'
            flash('Verification code has expired. Please request a new one.', 'error')
        except cognito_client.exceptions.InvalidPasswordException:
            errors['new_password'] = 'Password does not meet requirements'
            flash('Password does not meet requirements. It must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.', 'error')
        except Exception as e:
            logger.error(f"Password reset error: {e}")
            flash('An error occurred during password reset. Please try again.', 'error')

        return render_template('reset_password.html', email=email, errors=errors)

    return render_template('reset_password.html', email=email, errors={})

# Explore route with recommendations
@app.route('/explore')
def explore():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if db is None:
        logger.error("Database connection failed")
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('Explor.html', role=None, general_jobs=[], junior_jobs=[], posted_jobs=[], 
                             recommended_job_seekers=[], recommended_jobs=[], recommended_mentors=[],
                             recommended_users=[], unread_notifications=0, search_query='')

    users_collection = db['users']
    jobs_collection = db['jobs']
    applications_collection = db['applications']
    messages_collection = db['messages']
    notifications_collection = db['notifications']

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if not user:
        logger.error(f"User not found for ID: {session['user_id']}")
        flash('User not found.', 'error')
        return redirect(url_for('signin'))

    search_query = request.args.get('search', '').strip()
    role = user['role']
    general_jobs = []
    junior_jobs = []
    posted_jobs = []
    conversations = []
    suggested_users = []
    recent_message_notifications = []
    mentor_profile = None
    recommended_job_seekers = []
    recommended_jobs = []
    recommended_mentors = []
    recommended_users = []
    unread_notifications = get_unread_notifications_count(session['user_id'])

    if role == 'job_seeker':
        # Job Seeker: Fetch general and junior jobs
        search_filter = {}
        if search_query:
            search_filter = {
                '$or': [
                    {'job_title': {'$regex': search_query, '$options': 'i'}},
                    {'company_name': {'$regex': search_query, '$options': 'i'}},
                    {'location': {'$regex': search_query, '$options': 'i'}},
                    {'description': {'$regex': search_query, '$options': 'i'}}
                ]
            }

        # General Jobs
        general_query = {'category': {'$in': ['general']}}
        if search_filter:
            general_query.update(search_filter)
        general_jobs_cursor = jobs_collection.find(general_query)
        general_jobs = [
            {
                '_id': str(job['_id']),
                'job_title': job['job_title'],
                'company_name': job.get('company_name', 'Not specified'),
                'location': job.get('location', 'Not specified'),
                'job_type': job.get('job_type', 'Not specified'),
                'description': job['description'],
                'contact_email': job.get('contact_email', 'Not specified'),
                'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
            } for job in general_jobs_cursor
        ]
        logger.debug(f"General jobs found: {len(general_jobs)}")

        # Junior Jobs
        junior_query = {'category': {'$in': ['juniors']}}
        if search_filter:
            junior_query.update(search_filter)
        junior_jobs_cursor = jobs_collection.find(junior_query)
        junior_jobs = [
            {
                '_id': str(job['_id']),
                'job_title': job['job_title'],
                'company_name': job.get('company_name', 'Not specified'),
                'location': job.get('location', 'Not specified'),
                'job_type': job.get('job_type', 'Not specified'),
                'description': job['description'],
                'contact_email': job.get('contact_email', 'Not specified'),
                'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
            } for job in junior_jobs_cursor
        ]
        logger.debug(f"Junior jobs found: {len(junior_jobs)}")

        # Debug: Check all jobs in the collection
        all_jobs = jobs_collection.find()
        all_jobs_list = [
            {
                '_id': str(job['_id']),
                'job_title': job['job_title'],
                'category': job.get('category')
            } for job in all_jobs
        ]
        logger.debug(f"All jobs in collection: {all_jobs_list}")

        # Recommended Jobs (Enhanced)
        user_skills = user.get('skills', '').lower().split(',')
        user_skills = [skill.strip() for skill in user_skills if skill.strip()]
        skills_regex = '|'.join(user_skills)
        recommended_jobs_query = {
            '$or': [
                {'description': {'$regex': skills_regex, '$options': 'i'}},
                {'job_title': {'$regex': skills_regex, '$options': 'i'}}
            ]
        }
        if user.get('job_type'):
            recommended_jobs_query['job_type'] = user['job_type']
        if user.get('experience_level'):
            try:
                exp_level = map_experience_level(user['experience_level'])
                logger.debug(f"Filtering recommended jobs for experience_level: {exp_level}")
                recommended_jobs_query['experience_level'] = {
                    '$gte': exp_level - 1,
                    '$lte': exp_level + 1
                }
            except Exception as e:
                logger.error(f"Error processing experience_level for {user['email']}: {e}")
                # Fallback to no experience_level filter
        recommended_jobs_cursor = jobs_collection.find(recommended_jobs_query).limit(5)
        recommended_jobs = [
            {
                '_id': str(job['_id']),
                'job_title': job['job_title'],
                'company_name': job.get('company_name', 'Not specified'),
                'location': job.get('location', 'Not specified'),
                'job_type': job.get('job_type', 'Not specified'),
                'description': job['description'][:200] + '...' if len(job['description']) > 200 else job['description'],
                'contact_email': job.get('contact_email', 'Not specified'),
                'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
            } for job in recommended_jobs_cursor
        ]
        logger.debug(f"Recommended jobs found: {len(recommended_jobs)}")

        # Recommended Mentors
        if user_skills:
            recommended_mentors_query = {
                'role': 'mentor',
                'specialization': {'$regex': skills_regex, '$options': 'i'},
                '_id': {'$ne': ObjectId(session['user_id'])}
            }
            recommended_mentors_cursor = users_collection.find(recommended_mentors_query).limit(3)
            recommended_mentors = [
                {
                    'id': str(mentor['_id']),
                    'name': mentor['name'],
                    'specialization': mentor.get('specialization', 'Not specified')
                } for mentor in recommended_mentors_cursor
            ]
            logger.debug(f"Recommended mentors found: {len(recommended_mentors)}")

    elif role == 'job_poster':
        # Job Poster: Fetch posted jobs
        search_filter = {}
        if search_query:
            search_filter = {
                '$or': [
                    {'job_title': {'$regex': search_query, '$options': 'i'}},
                    {'company_name': {'$regex': search_query, '$options': 'i'}},
                    {'location': {'$regex': search_query, '$options': 'i'}},
                    {'description': {'$regex': search_query, '$options': 'i'}}
                ]
            }

        posted_jobs_query = {'posted_by': ObjectId(session['user_id'])}
        if search_filter:
            posted_jobs_query.update(search_filter)
        posted_jobs_cursor = jobs_collection.find(posted_jobs_query)
        posted_jobs = []
        for job in posted_jobs_cursor:
            application_count = applications_collection.count_documents({'job_id': job['_id']})
            posted_jobs.append({
                '_id': str(job['_id']),
                'job_title': job['job_title'],
                'company_name': job.get('company_name', 'Not specified'),
                'location': job.get('location', 'Not specified'),
                'job_type': job.get('job_type', 'Not specified'),
                'description': job['description'],
                'contact_email': job.get('contact_email', 'Not specified'),
                'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified',
                'application_count': application_count
            })
        logger.debug(f"Posted jobs found for user {session['user_id']}: {len(posted_jobs)}")

        # Recommended Job Seekers
        posted_jobs_cursor = jobs_collection.find({'posted_by': ObjectId(session['user_id'])})
        job_descriptions = ' '.join([job['description'].lower() + ' ' + job['job_title'].lower() for job in posted_jobs_cursor])
        job_keywords = set(job_descriptions.split()) - set(['and', 'or', 'the', 'a', 'an', 'in', 'to', 'for'])
        keywords_regex = '|'.join([re.escape(keyword) for keyword in job_keywords if len(keyword) > 3])
        if keywords_regex:
            recommended_seekers_query = {
                'role': 'job_seeker',
                'skills': {'$regex': keywords_regex, '$options': 'i'},
                '_id': {'$ne': ObjectId(session['user_id'])}
            }
            recommended_seekers_cursor = users_collection.find(recommended_seekers_query).limit(5)
            recommended_job_seekers = [
                {
                    'id': str(seeker['_id']),
                    'name': seeker['name'],
                    'skills': seeker.get('skills', 'Not specified'),
                    'experience_level': map_experience_level(seeker.get('experience_level', 1))
                } for seeker in recommended_seekers_cursor
            ]
            logger.debug(f"Recommended job seekers found: {len(recommended_job_seekers)}")

        # Recommended Mentors
        if keywords_regex:
            recommended_mentors_query = {
                'role': 'mentor',
                'specialization': {'$regex': keywords_regex, '$options': 'i'},
                '_id': {'$ne': ObjectId(session['user_id'])}
            }
            recommended_mentors_cursor = users_collection.find(recommended_mentors_query).limit(3)
            recommended_mentors = [
                {
                    'id': str(mentor['_id']),
                    'name': mentor['name'],
                    'specialization': mentor.get('specialization', 'Not specified')
                } for mentor in recommended_mentors_cursor
            ]
            logger.debug(f"Recommended mentors found: {len(recommended_mentors)}")

    elif role == 'mentor':
        # Mentor: Fetch conversations and suggested users
        mentor_profile = {
            'name': user['name'],
            'specialization': user.get('specialization', 'Not specified')
        }

        received_messages = messages_collection.distinct('sender_id', {'receiver_id': ObjectId(session['user_id'])})
        for user_id in received_messages:
            contact = users_collection.find_one({'_id': user_id})
            if contact:
                recent_message = messages_collection.find_one(
                    {
                        '$or': [
                            {'sender_id': ObjectId(session['user_id']), 'receiver_id': user_id},
                            {'sender_id': user_id, 'receiver_id': ObjectId(session['user_id'])}
                        ]
                    },
                    sort=[('timestamp', -1)]
                )
                message_snippet = recent_message['message'][:50] + '...' if recent_message and len(recent_message['message']) > 50 else recent_message['message'] if recent_message else ''
                conversations.append({
                    'id': str(contact['_id']),
                    'name': contact['name'],
                    'role': contact['role'],
                    'message_snippet': message_snippet,
                    'timestamp': recent_message['timestamp'] if recent_message else None
                })

        search_filter = {}
        if search_query:
            search_filter = {
                '$or': [
                    {'name': {'$regex': search_query, '$options': 'i'}},
                    {'skills': {'$regex': search_query, '$options': 'i'}},
                    {'company_name': {'$regex': search_query, '$options': 'i'}}
                ]
            }

        if search_query:
            conversations = [
                convo for convo in conversations
                if search_query.lower() in convo['name'].lower() or
                   (convo['role'] == 'job_seeker' and search_query.lower() in users_collection.find_one({'_id': ObjectId(convo['id'])}).get('skills', '').lower())
            ]

        contacted_user_ids = [ObjectId(user['id']) for user in conversations]
        suggested_query = {
            'role': {'$in': ['job_seeker', 'job_poster']},
            '_id': {'$nin': contacted_user_ids + [ObjectId(session['user_id'])]}
        }
        if mentor_profile['specialization']:
            suggested_query['$or'] = [
                {'skills': {'$regex': mentor_profile['specialization'], '$options': 'i'}},
                {'specialization': {'$regex': mentor_profile['specialization'], '$options': 'i'}}
            ]
        suggested_users_cursor = users_collection.find(suggested_query).limit(5)
        for suggested_user in suggested_users_cursor:
            suggested_users.append({
                'id': str(suggested_user['_id']),
                'name': suggested_user['name'],
                'role': suggested_user['role'],
                'skills': suggested_user.get('skills', 'Not specified') if suggested_user['role'] == 'job_seeker' else None,
                'description': f"Looking for {suggested_user['job_type']}" if suggested_user['role'] == 'job_seeker' else 'Job Poster'
            })

        recent_notifications = notifications_collection.find({
            'user_id': ObjectId(session['user_id']),
            'type': 'new_message',
            'read': False
        }).sort('created_at', -1).limit(3)
        recent_message_notifications = [
            {
                'message': notification['message'],
                'contact_id': str(notification['contact_id']),
                'created_at': notification['created_at']
            }
            for notification in recent_notifications
        ]

        # Recommended Users
        specialization = user.get('specialization', '').lower()
        if specialization:
            recommended_users_query = {
                'role': {'$in': ['job_seeker', 'job_poster']},
                '$or': [
                    {'skills': {'$regex': specialization, '$options': 'i'}},
                    {'job_type': {'$regex': specialization, '$options': 'i'}}
                ],
                '_id': {'$nin': contacted_user_ids + [ObjectId(session['user_id'])]}
            }
            recommended_users_cursor = users_collection.find(recommended_users_query).limit(5)
            recommended_users = [
                {
                    'id': str(u['_id']),
                    'name': u['name'],
                    'role': u['role'],
                    'skills': u.get('skills', 'Not specified') if u['role'] == 'job_seeker' else None,
                    'job_type': u.get('job_type', 'Not specified') if u['role'] == 'job_seeker' else None
                } for u in recommended_users_cursor
            ]
            logger.debug(f"Recommended users found for mentor: {len(recommended_users)}")

    return render_template('Explor.html', role=role, general_jobs=general_jobs, junior_jobs=junior_jobs, 
                          posted_jobs=posted_jobs, conversations=conversations, suggested_users=suggested_users,
                          recent_message_notifications=recent_message_notifications, mentor_profile=mentor_profile,
                          recommended_job_seekers=recommended_job_seekers, recommended_jobs=recommended_jobs,
                          recommended_mentors=recommended_mentors, recommended_users=recommended_users,
                          unread_notifications=unread_notifications, search_query=search_query)

# Post Job route
@app.route('/postjob', methods=['GET', 'POST'])
def post_job():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_poster':
        flash('Only Job Posters can post jobs.', 'error')
        return redirect(url_for('explore'))

    unread_notifications = get_unread_notifications_count(session['user_id'])

    job_types = [
        {'value': 'full-time', 'label': 'Full-time'},
        {'value': 'part-time', 'label': 'Part-time'},
        {'value': 'contract', 'label': 'Contract'},
        {'value': 'internship', 'label': 'Internship'},
        {'value': 'remote', 'label': 'Remote'}
    ]

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('postjob.html', form_data={}, errors={}, job_types=job_types, unread_notifications=unread_notifications)

    jobs_collection = db['jobs']

    form_data = {
        'company_name': '',
        'job_title': '',
        'job_type': '',
        'category': [],
        'location': '',
        'description': '',
        'company_description': '',
        'contact_email': '',
        'deadline': '',
        'experience_level': ''
    }
    errors = {}

    if request.method == 'POST':
        form_data = {
            'company_name': request.form.get('company-name', '').strip(),
            'job_title': request.form.get('job-title', '').strip(),
            'job_type': request.form.get('job-type', '').strip(),
            'category': request.form.getlist('category'),
            'location': request.form.get('job-location', '').strip(),
            'description': request.form.get('job-description', '').strip(),
            'company_description': request.form.get('company-description', '').strip(),
            'contact_email': request.form.get('contact-email', '').strip(),
            'deadline': request.form.get('deadline', '').strip(),
            'experience_level': request.form.get('experience-level', '').strip()
        }

        # Validate form fields
        if not form_data['company_name']:
            errors['company_name'] = 'Company name is required'
        if not form_data['job_title']:
            errors['job_title'] = 'Job title is required'
        if not form_data['job_type']:
            errors['job_type'] = 'Job type is required'
        if not form_data['category']:
            errors['category'] = 'At least one category (General or Juniors) must be selected'
        else:
            valid_categories = ['general', 'juniors']
            form_data['category'] = [cat for cat in form_data['category'] if cat in valid_categories]
            if not form_data['category']:
                errors['category'] = 'Invalid category selected'
        if not form_data['location']:
            errors['location'] = 'Location is required'
        if not form_data['description']:
            errors['description'] = 'Job description is required'
        if not form_data['contact_email']:
            errors['contact_email'] = 'Contact email is required'
        else:
            email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_pattern.match(form_data['contact_email']):
                errors['contact_email'] = 'Invalid email format'
        if not form_data['deadline']:
            errors['deadline'] = 'Deadline is required'
        else:
            try:
                deadline_date = datetime.strptime(form_data['deadline'], '%Y-%m-%d')
                if deadline_date < datetime.utcnow():
                    errors['deadline'] = 'Deadline must be in the future'
            except ValueError:
                errors['deadline'] = 'Invalid date format (use YYYY-MM-DD)'
        if form_data['experience_level']:
            if not validate_experience_level(form_data['experience_level']):
                errors['experience_level'] = 'Experience level must be between 1 and 5'
            else:
                form_data['experience_level'] = int(form_data['experience_level'])

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('postjob.html', form_data=form_data, errors=errors, job_types=job_types, unread_notifications=unread_notifications)

        job = {
            'company_name': form_data['company_name'],
            'job_title': form_data['job_title'],
            'job_type': form_data['job_type'],
            'category': form_data['category'],  # Ensure this is a list
            'location': form_data['location'],
            'description': form_data['description'],
            'company_description': form_data['company_description'] or None,
            'contact_email': form_data['contact_email'],
            'deadline': datetime.strptime(form_data['deadline'], '%Y-%m-%d'),
            'posted_by': ObjectId(session['user_id']),
            'created_at': datetime.utcnow(),
            'application_count': 0,
            'experience_level': form_data['experience_level'] if form_data['experience_level'] else None
        }

        try:
            result = jobs_collection.insert_one(job)
            logger.info(f"Inserted job: {job['job_title']} by {job['company_name']}")
            flash('Job posted successfully!', 'success')
            return redirect(url_for('explore'))
        except Exception as e:
            logger.error(f"Error inserting job: {e}")
            flash('Failed to post job. Please try again later.', 'error')
            return render_template('postjob.html', form_data=form_data, errors=errors, job_types=job_types, unread_notifications=unread_notifications)

    return render_template('postjob.html', form_data=form_data, errors=errors, job_types=job_types, unread_notifications=unread_notifications)

# Apply for Job route
@app.route('/apply_job/<job_id>', methods=['POST'])
def apply_job(job_id):
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can apply for jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return redirect(url_for('explore'))

    applications_collection = db['applications']
    jobs_collection = db['jobs']
    users_collection = db['users']
    notifications_collection = db['notifications']

    job = jobs_collection.find_one({'_id': ObjectId(job_id)})
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('explore'))

    job_seeker = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if not job_seeker:
        flash('User not found.', 'error')
        return redirect(url_for('explore'))

    if applications_collection.find_one({'job_id': ObjectId(job_id), 'user_id': ObjectId(session['user_id'])}):
        flash('You have already applied for this job.', 'error')
        return redirect(url_for('explore'))

    application = {
        'job_id': ObjectId(job_id),
        'user_id': ObjectId(session['user_id']),
        'status': 'pending',
        'applied_at': datetime.utcnow()
    }
    application_result = applications_collection.insert_one(application)
    application_id = application_result.inserted_id

    # Update the application_count in the jobs collection
    jobs_collection.update_one(
        {'_id': ObjectId(job_id)},
        {'$inc': {'application_count': 1}}
    )

    job_poster_id = job['posted_by']
    notification_message = f"{job_seeker['name']} has applied for your job: {job['job_title']}"
    notifications_collection.insert_one({
        'user_id': job_poster_id,
        'type': 'application',
        'message': notification_message,
        'job_id': ObjectId(job_id),
        'application_id': application_id,
        'read': False,
        'created_at': datetime.utcnow()
    })

    flash('Application submitted successfully!', 'success')
    return redirect(url_for('applications'))

# View Applications (Job Seeker)
@app.route('/applications')
def applications():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can view their applications.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('applications.html', applications=[])

    applications_collection = db['applications']
    jobs_collection = db['jobs']

    user_applications = applications_collection.find({'user_id': ObjectId(session['user_id'])})
    applications_list = []
    for app in user_applications:
        job = jobs_collection.find_one({'_id': app['job_id']})
        if job:
            applications_list.append({
                'application_id': str(app['_id']),
                'job_title': job['job_title'],
                'company_name': job.get('company_name', 'Not specified'),
                'location': job.get('location', 'Not specified'),
                'job_type': job.get('job_type', 'Not specified'),
                'description': job['description'],
                'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified',
                'status': app['status'],
                'applied_at': app['applied_at']
            })

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('applications.html', applications=applications_list, unread_notifications=unread_notifications)

# View Applications (Job Poster)
@app.route('/view_applications')
def view_applications():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_poster':
        flash('Only Job Posters can view job applications.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('view_applications.html', applications=[])

    jobs_collection = db['jobs']
    applications_collection = db['applications']
    users_collection = db['users']

    job_id = request.args.get('job_id')
    query = {'posted_by': ObjectId(session['user_id'])}
    if job_id:
        query['_id'] = ObjectId(job_id)
    posted_jobs = jobs_collection.find(query)

    applications_list = []
    for job in posted_jobs:
        job_applications = applications_collection.find({'job_id': job['_id']})
        for app in job_applications:
            applicant = users_collection.find_one({'_id': app['user_id']})
            if applicant:
                applications_list.append({
                    'application_id': str(app['_id']),
                    'job_id': str(job['_id']),
                    'job_title': job['job_title'],
                    'company_name': job.get('company_name', 'Not specified'),
                    'location': job.get('location', 'Not specified'),
                    'job_type': job.get('job_type', 'Not specified'),
                    'description': job['description'],
                    'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                    'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified',
                    'applicant_name': applicant['name'],
                    'applicant_email': applicant['email'],
                    'resume': applicant.get('resume', 'No resume provided'),
                    'status': app['status'],
                    'applied_at': app['applied_at']
                })

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('view_applications.html', applications=applications_list, unread_notifications=unread_notifications)

# Update Application Status (Job Poster)
@app.route('/update_application_status/<application_id>/<status>', methods=['POST'])
def update_application_status(application_id, status):
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_poster':
        flash('Only Job Posters can update application status.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return redirect(url_for('view_applications'))

    applications_collection = db['applications']
    jobs_collection = db['jobs']
    users_collection = db['users']
    notifications_collection = db['notifications']

    if status not in ['accepted', 'rejected']:
        flash('Invalid status.', 'error')
        return redirect(url_for('view_applications'))

    application = applications_collection.find_one({'_id': ObjectId(application_id)})
    if not application:
        flash('Application not found.', 'error')
        return redirect(url_for('view_applications'))

    job = jobs_collection.find_one({'_id': application['job_id'], 'posted_by': ObjectId(session['user_id'])})
    if not job:
        flash('You are not authorized to update this application.', 'error')
        return redirect(url_for('view_applications'))

    applications_collection.update_one(
        {'_id': ObjectId(application_id)},
        {'$set': {'status': status}}
    )

    job_seeker_id = application['user_id']
    job_seeker = users_collection.find_one({'_id': job_seeker_id})
    if job_seeker:
        notification_message = f"Your application for {job['job_title']} has been {status}."
        notifications_collection.insert_one({
            'user_id': job_seeker_id,
            'type': 'status_update',
            'message': notification_message,
            'job_id': job['_id'],
            'application_id': ObjectId(application_id),
            'read': False,
            'created_at': datetime.utcnow()
        })

    flash(f'Application {status} successfully!', 'success')
    return redirect(url_for('view_applications'))

# View Application Details (Job Poster)
@app.route('/view_application_details/<application_id>')
def view_application_details(application_id):
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_poster':
        flash('Only Job Posters can view application details.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return redirect(url_for('view_applications'))

    applications_collection = db['applications']
    jobs_collection = db['jobs']
    users_collection = db['users']
    notifications_collection = db['notifications']

    application = applications_collection.find_one({'_id': ObjectId(application_id)})
    if not application:
        flash('Application not found.', 'error')
        return redirect(url_for('view_applications'))

    job = jobs_collection.find_one({'_id': application['job_id'], 'posted_by': ObjectId(session['user_id'])})
    if not job:
        flash('You are not authorized to view this application.', 'error')
        return redirect(url_for('view_applications'))

    applicant = users_collection.find_one({'_id': application['user_id']})
    if not applicant:
        flash('Applicant not found.', 'error')
        return redirect(url_for('view_applications'))

    notification_message = f"Your resume for {job['job_title']} has been viewed by the job poster."
    notifications_collection.insert_one({
        'user_id': applicant['_id'],
        'type': 'resume_viewed',
        'message': notification_message,
        'job_id': job['_id'],
        'application_id': ObjectId(application_id),
        'read': False,
        'created_at': datetime.utcnow()
    })

    application_details = {
        'application_id': str(application['_id']),
        'job_title': job['job_title'],
        'company_name': job.get('company_name', 'Not specified'),
        'location': job.get('location', 'Not specified'),
        'job_type': job.get('job_type', 'Not specified'),
        'description': job['description'],
        'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
        'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified',
        'applicant_name': applicant['name'],
        'applicant_email': applicant['email'],
        'resume': applicant.get('resume', 'No resume provided'),
        'status': application['status'],
        'applied_at': application['applied_at'],
        'skills': applicant.get('skills', 'Not provided'),
        'education_level': applicant.get('education_level', 'Not provided'),
        'experience_level': map_experience_level(applicant.get('experience_level', 1))
    }

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('view_application_details.html', application=application_details, unread_notifications=unread_notifications)

# Save Job route (Job Seeker)
@app.route('/save_job/<job_id>', methods=['POST'])
def save_job(job_id):
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can save jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return redirect(url_for('explore'))

    users_collection = db['users']
    jobs_collection = db['jobs']

    job = jobs_collection.find_one({'_id': ObjectId(job_id)})
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('explore'))

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if ObjectId(job_id) in user.get('saved_jobs', []):
        flash('Job already saved.', 'error')
        return redirect(url_for('explore'))

    users_collection.update_one(
        {'_id': ObjectId(session['user_id'])},
        {'$addToSet': {'saved_jobs': ObjectId(job_id)}}
    )
    flash('Job saved successfully!', 'success')
    return redirect(url_for('saved'))

# Unsave Job route (Job Seeker)
@app.route('/unsave_job/<job_id>', methods=['POST'])
def unsave_job(job_id):
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can unsave jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return redirect(url_for('saved'))

    users_collection = db['users']
    jobs_collection = db['jobs']

    job = jobs_collection.find_one({'_id': ObjectId(job_id)})
    if not job:
        flash('Job not found.', 'error')
        return redirect(url_for('saved'))

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if ObjectId(job_id) not in user.get('saved_jobs', []):
        flash('Job not found in your saved list.', 'error')
        return redirect(url_for('saved'))

    users_collection.update_one(
        {'_id': ObjectId(session['user_id'])},
        {'$pull': {'saved_jobs': ObjectId(job_id)}}
    )
    flash('Job unsaved successfully!', 'success')
    return redirect(url_for('saved'))

# View Saved Jobs (Job Seeker)
@app.route('/saved')
def saved():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can view saved jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('saved.html', saved_jobs=[])

    users_collection = db['users']
    jobs_collection = db['jobs']

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    saved_jobs = []
    if user.get('saved_jobs'):
        for job_id in user['saved_jobs']:
            job = jobs_collection.find_one({'_id': job_id})
            if job:
                saved_jobs.append({
                    '_id': str(job['_id']),
                    'job_title': job['job_title'],
                    'company_name': job.get('company_name', 'Not specified'),
                    'location': job.get('location', 'Not specified'),
                    'job_type': job.get('job_type', 'Not specified'),
                    'description': job['description'],
                    'contact_email': job.get('contact_email', 'Not specified'),
                    'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
                    'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
                })

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('saved.html', saved_jobs=saved_jobs, unread_notifications=unread_notifications)

# Contact Us route
@app.route('/contactus', methods=['GET', 'POST'])
def contactus():
    form_data = {
        'question': '',
        'name': session.get('user_name', ''),
        'email': '',
        'phone': '',
        'message': ''
    }
    errors = {}

    if request.method == 'POST':
        if db is None:
            flash('Database connection failed. Please try again later.', 'error')
            return render_template('contactus.html', form_data=form_data, errors=errors)

        inquiries_collection = db['inquiries']

        form_data = {
            'question': request.form.get('question', ''),
            'name': request.form.get('name', ''),
            'email': request.form.get('email', '').lower(),
            'phone': request.form.get('phone', ''),
            'message': request.form.get('message', '')
        }

        if not form_data['question']:
            errors['question'] = 'Question type is required'
        if not form_data['name']:
            errors['name'] = 'Name is required'
        if not form_data['email']:
            errors['email'] = 'Email is required'
        if not form_data['message']:
            errors['message'] = 'Message is required'

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('contactus.html', form_data=form_data, errors=errors)

        inquiry = {
            'question_type': form_data['question'],
            'name': form_data['name'],
            'email': form_data['email'],
            'phone': form_data['phone'] or None,
            'message': form_data['message'],
            'created_at': datetime.utcnow(),
            'user_id': ObjectId(session['user_id']) if 'user_id' in session else None
        }
        inquiries_collection.insert_one(inquiry)
        flash('Your message has been sent!', 'success')
        return redirect(url_for('contactus'))

    unread_notifications = get_unread_notifications_count(session['user_id']) if 'user_id' in session else 0
    return render_template('contactus.html', form_data=form_data, errors=errors, unread_notifications=unread_notifications)

# Profile route
@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('profile.html', user=None)

    users_collection = db['users']

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('signin'))

    user['experience_level'] = map_experience_level(user.get('experience_level', 1))
    logger.debug(f"User data for profile: {user}")

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('profile.html', user=user, unread_notifications=unread_notifications)

# Edit Profile route
@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('edit_profile.html', user=None, errors={})

    users_collection = db['users']
    applications_collection = db['applications']
    jobs_collection = db['jobs']
    messages_collection = db['messages']
    notifications_collection = db['notifications']

    user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('signin'))

    education_levels = [
        {'value': 'high_school', 'label': 'High School'},
        {'value': 'bachelor', 'label': "Bachelor's Degree"},
        {'value': 'master', 'label': "Master's Degree"},
        {'value': 'phd', 'label': 'PhD'}
    ]
    job_types = [
        {'value': 'full-time', 'label': 'Full-time'},
        {'value': 'part-time', 'label': 'Part-time'},
        {'value': 'contract', 'label': 'Contract'},
        {'value': 'internship', 'label': 'Internship'},
        {'value': 'remote', 'label': 'Remote'}
    ]
    roles = [
        {'value': 'job_seeker', 'label': 'Job Seeker'},
        {'value': 'job_poster', 'label': 'Job Poster'},
        {'value': 'mentor', 'label': 'Mentor'}
    ]

    if request.method == 'POST':
        action = request.form.get('action', '').strip()
        
        if action == 'delete_account':
            try:
                # Delete related data from MongoDB
                applications_collection.delete_many({'user_id': ObjectId(session['user_id'])})
                jobs_collection.delete_many({'posted_by': ObjectId(session['user_id'])})
                messages_collection.delete_many({
                    '$or': [
                        {'sender_id': ObjectId(session['user_id'])},
                        {'receiver_id': ObjectId(session['user_id'])}
                    ]
                })
                notifications_collection.delete_many({'user_id': ObjectId(session['user_id'])})
                users_collection.delete_one({'_id': ObjectId(session['user_id'])})

                # Delete user from Cognito
                cognito_client.admin_delete_user(
                    UserPoolId=COGNITO_USER_POOL_ID,
                    Username=user['email'].lower()
                )
                logger.info(f"User {user['email']} deleted successfully")
                
                session.clear()
                flash('Your account has been deleted successfully.', 'success')
                return redirect(url_for('home'))
            except Exception as e:
                logger.error(f"Error deleting account for {user['email']}: {e}")
                flash('Failed to delete account. Please try again later.', 'error')
                return render_template('edit_profile.html', user=user, errors={}, education_levels=education_levels,
                                     job_types=job_types, roles=roles, unread_notifications=get_unread_notifications_count(session['user_id']))

        # Handle profile update
        form_data = {
            'Name': request.form.get('Name', '').strip(),
            'Email': request.form.get('Email', '').strip().lower(),
            'Skills': request.form.get('Skills', '').strip(),
            'Education_level': request.form.get('Education_level', '').strip(),
            'Job_type': request.form.get('Job_type', '').strip(),
            'Resume': request.form.get('Resume', '').strip(),
            'Experience_levelID': request.form.get('Experience_levelID', '').strip(),
            'Specialization': request.form.get('Specialization', '').strip(),
            'Role': request.form.get('Role', '').strip(),
            'Company_name': request.form.get('Company_name', '').strip() if request.form.get('Role') == 'job_poster' else ''
        }
        errors = {}

        # Validate common mandatory fields
        if not form_data['Name']:
            errors['Name'] = 'Full name is required'
        if not form_data['Email']:
            errors['Email'] = 'Email is required'
        else:
            email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
            if not email_pattern.match(form_data['Email']):
                errors['Email'] = 'Invalid email format'
        if not form_data['Role']:
            errors['Role'] = 'Role is required'

        # Role-specific validations
        if form_data['Role'] == 'job_seeker':
            if not form_data['Job_type']:
                errors['Job_type'] = 'Preferred job type is required for job seekers'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for job seekers'
        elif form_data['Role'] == 'job_poster':
            if not form_data['Company_name']:
                errors['Company_name'] = 'Company name is required for job posters'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for job posters'
        elif form_data['Role'] == 'mentor':
            if not form_data['Specialization']:
                errors['Specialization'] = 'Specialization is required for mentors'
            if not form_data['Resume']:
                errors['Resume'] = 'Resume link is required for mentors'

        # Validate experience level
        if form_data['Experience_levelID']:
            if not validate_experience_level(form_data['Experience_levelID']):
                errors['Experience_levelID'] = 'Experience level must be between 1 and 5'
            else:
                form_data['Experience_levelID'] = int(form_data['Experience_levelID'])

        if errors:
            flash('Please correct the errors in the form', 'error')
            return render_template('edit_profile.html', user=user, form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles,
                                 unread_notifications=get_unread_notifications_count(session['user_id']))

        # Check if email is changed and already exists
        if form_data['Email'] != user['email']:
            try:
                cognito_client.admin_get_user(
                    UserPoolId=COGNITO_USER_POOL_ID,
                    Username=form_data['Email']
                )
                errors['Email'] = 'Email already registered'
                flash('Email already registered!', 'error')
                return render_template('edit_profile.html', user=user, form_data=form_data, errors=errors,
                                     education_levels=education_levels, job_types=job_types, roles=roles,
                                     unread_notifications=get_unread_notifications_count(session['user_id']))
            except cognito_client.exceptions.UserNotFoundException:
                pass  # Email is available

        # Update user in MongoDB
        update_data = {
            'name': form_data['Name'],
            'email': form_data['Email'],
            'role': form_data['Role'],
            'skills': form_data['Skills'] or None,
            'education_level': form_data['Education_level'] or None,
            'job_type': form_data['Job_type'] or None,
            'resume': form_data['Resume'],
            'experience_level': form_data['Experience_levelID'] if form_data['Experience_levelID'] else None,
            'specialization': form_data['Specialization'] or None,
            'company_name': form_data['Company_name'] if form_data['Role'] == 'job_poster' else None,
            'updated_at': datetime.utcnow()
        }

        try:
            users_collection.update_one(
                {'_id': ObjectId(session['user_id'])},
                {'$set': update_data}
            )
            logger.info(f"Updated MongoDB user data for {form_data['Email']}")
        except Exception as e:
            logger.error(f"MongoDB update error for {form_data['Email']}: {e}")
            flash('Failed to update profile. Please try again.', 'error')
            return render_template('edit_profile.html', user=user, form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles,
                                 unread_notifications=get_unread_notifications_count(session['user_id']))

        # Update user attributes in Cognito
        try:
            user_attributes = [
                {'Name': 'name', 'Value': form_data['Name']},
                {'Name': 'email', 'Value': form_data['Email']},
                {'Name': 'custom:role', 'Value': form_data['Role']},
                {'Name': 'custom:skills', 'Value': form_data['Skills'] or ''},
                {'Name': 'custom:education_level', 'Value': form_data['Education_level'] or ''},
                {'Name': 'custom:job_type', 'Value': form_data['Job_type'] or ''},
                {'Name': 'custom:resume', 'Value': form_data['Resume']},
                {'Name': 'custom:experience_level', 'Value': str(form_data['Experience_levelID']) if form_data['Experience_levelID'] else ''},
                {'Name': 'custom:specialization', 'Value': form_data['Specialization'] or ''},
                {'Name': 'custom:company_name', 'Value': form_data['Company_name'] or ''}
            ]
            cognito_client.admin_update_user_attributes(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=user['email'].lower(),
                UserAttributes=user_attributes
            )
            logger.info(f"Updated Cognito user attributes for {form_data['Email']}")

            # If email changed, update Cognito username
            if form_data['Email'] != user['email']:
                cognito_client.admin_update_user_attributes(
                    UserPoolId=COGNITO_USER_POOL_ID,
                    Username=user['email'].lower(),
                    UserAttributes=[{'Name': 'email', 'Value': form_data['Email']}]
                )
                logger.info(f"Updated Cognito email for {form_data['Email']}")
        except Exception as e:
            logger.error(f"Cognito update error for {form_data['Email']}: {e}")
            flash('Failed to update profile in authentication system. Please try again.', 'error')
            return render_template('edit_profile.html', user=user, form_data=form_data, errors=errors,
                                 education_levels=education_levels, job_types=job_types, roles=roles,
                                 unread_notifications=get_unread_notifications_count(session['user_id']))

        # Update session if role or name changed
        session['user_name'] = form_data['Name']
        session['user_role'] = form_data['Role']
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('edit_profile.html', user=user, form_data=user, errors={},
                          education_levels=education_levels, job_types=job_types, roles=roles,
                          unread_notifications=unread_notifications)
    
# Logout route
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('home'))

# Juniors route
@app.route('/juniors')
def juniors():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can view junior jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('juniors.html', jobs=[], search_query='')

    jobs_collection = db['jobs']
    
    search_query = request.args.get('search', '').strip()
    query = {'category': {'$in': ['juniors']}}
    
    if search_query:
        query.update({
            '$or': [
                {'job_title': {'$regex': search_query, '$options': 'i'}},
                {'company_name': {'$regex': search_query, '$options': 'i'}},
                {'location': {'$regex': search_query, '$options': 'i'}},
                {'description': {'$regex': search_query, '$options': 'i'}}
            ]
        })

    jobs = jobs_collection.find(query)
    jobs_list = [
        {
            '_id': str(job['_id']),
            'job_title': job['job_title'],
            'company_name': job.get('company_name', 'Not specified'),
            'location': job.get('location', 'Not specified'),
            'job_type': job.get('job_type', 'Not specified'),
            'description': job['description'],
            'contact_email': job.get('contact_email', 'Not specified'),
            'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
            'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
        } for job in jobs
    ]
    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('juniors.html', jobs=jobs_list, unread_notifications=unread_notifications, search_query=search_query)

# General route
@app.route('/general')
def general():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if session.get('user_role') != 'job_seeker':
        flash('Only Job Seekers can view general jobs.', 'error')
        return redirect(url_for('explore'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('general.html', jobs=[], search_query='')

    jobs_collection = db['jobs']
    
    search_query = request.args.get('search', '').strip()
    query = {'category': {'$in': ['general']}}
    
    if search_query:
        query.update({
            '$or': [
                {'job_title': {'$regex': search_query, '$options': 'i'}},
                {'company_name': {'$regex': search_query, '$options': 'i'}},
                {'location': {'$regex': search_query, '$options': 'i'}},
                {'description': {'$regex': search_query, '$options': 'i'}}
            ]
        })

    jobs = jobs_collection.find(query)
    jobs_list = [
        {
            '_id': str(job['_id']),
            'job_title': job['job_title'],
            'company_name': job.get('company_name', 'Not specified'),
            'location': job.get('location', 'Not specified'),
            'job_type': job.get('job_type', 'Not specified'),
            'description': job['description'],
            'contact_email': job.get('contact_email', 'Not specified'),
            'deadline': job['deadline'].strftime('%Y-%m-%d') if job.get('deadline') else 'Not specified',
            'created_at': job['created_at'].strftime('%Y-%m-%d') if job.get('created_at') else 'Not specified'
        } for job in jobs
    ]
    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('general.html', jobs=jobs_list, unread_notifications=unread_notifications, search_query=search_query)

# Mark Notifications as Read (AJAX endpoint)
@app.route('/mark_notifications_read', methods=['POST'])
def mark_notifications_read():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'}), 401

    if db is None:
        return jsonify({'success': False, 'message': 'Database connection failed'}), 500

    notifications_collection = db['notifications']
    try:
        notifications_collection.update_many(
            {'user_id': ObjectId(session['user_id']), 'read': False},
            {'$set': {'read': True}}
        )
        return jsonify({'success': True, 'message': 'Notifications marked as read'})
    except Exception as e:
        logger.error(f"Error marking notifications as read: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

# Notifications route
@app.route('/notifications')
def notifications():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if db is None:
        flash('Database connection failed. Please try again later.', 'error')
        return render_template('notifications.html', notifications=[])

    notifications_collection = db['notifications']
    user_notifications = notifications_collection.find({'user_id': ObjectId(session['user_id'])}).sort('created_at', -1)
    notifications_list = [
        {
            'id': str(notification['_id']),
            'type': notification['type'],
            'message': notification['message'],
            'read': notification['read'],
            'created_at': notification['created_at'],
            'job_id': str(notification['job_id']) if 'job_id' in notification else None,
            'application_id': str(notification['application_id']) if 'application_id' in notification else None,
            'contact_id': str(notification['contact_id']) if 'contact_id' in notification else None
        }
        for notification in user_notifications
    ]

    notifications_collection.update_many(
        {'user_id': ObjectId(session['user_id']), 'read': False},
        {'$set': {'read': True}}
    )

    unread_notifications = get_unread_notifications_count(session['user_id'])
    return render_template('notifications.html', notifications=notifications_list, unread_notifications=unread_notifications)

# About route
@app.route('/about')
def about():
    unread_notifications = get_unread_notifications_count(session['user_id']) if 'user_id' in session else 0
    return render_template('about.html', unread_notifications=unread_notifications)

if __name__ == '__main__':
    app.run(debug=True)