import pymongo
from bson import ObjectId
from datetime import datetime, timedelta
import urllib.parse
import certifi
from dotenv import load_dotenv
import os
import boto3

# Load environment variables
load_dotenv()

# AWS Cognito Configuration
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
COGNITO_USER_POOL_ID = os.getenv('COGNITO_USER_POOL_ID')
COGNITO_CLIENT_ID = os.getenv('COGNITO_CLIENT_ID')

# Initialize Cognito client
try:
    cognito_client = boto3.client('cognito-idp', region_name=AWS_REGION)
    print("Connected to AWS Cognito successfully!")
except Exception as e:
    print(f"Failed to connect to AWS Cognito: {e}")
    exit(1)

# MongoDB Atlas Configuration
mongo_username = urllib.parse.quote_plus(os.getenv('MONGO_USERNAME', 'hyrup_admin'))
mongo_password = urllib.parse.quote_plus(os.getenv('MONGO_PASSWORD', 'Memo@2009'))
mongo_cluster = os.getenv('MONGO_CLUSTER', 'hyrup-cluster.dz2tlrn.mongodb.net')
mongo_dbname = os.getenv('MONGO_DBNAME', 'hyrup_db')

mongo_uri = f"mongodb+srv://{mongo_username}:{mongo_password}@{mongo_cluster}/{mongo_dbname}?retryWrites=true&w=majority"

# Connect to MongoDB Atlas
try:
    client = pymongo.MongoClient(mongo_uri, tlsCAFile=certifi.where(), serverSelectionTimeoutMS=5000)
    client.server_info()  # Test connection
    print("Connected to MongoDB Atlas successfully!")
except Exception as e:
    print(f"Failed to connect to MongoDB Atlas: {e}")
    exit(1)

db = client[mongo_dbname]
users_collection = db["users"]
jobs_collection = db["jobs"]

# Check for duplicate email in MongoDB
def is_email_unique(email):
    return users_collection.find_one({"email": email}) is None

# Register user in Cognito and MongoDB
def register_user(user_data, password):
    email = user_data["email"].lower()
    if not is_email_unique(email):
        print(f"Skipped user: {email} (email already exists in MongoDB)")
        return None

    # Check if user already exists in Cognito
    try:
        cognito_client.admin_get_user(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=email
        )
        print(f"Skipped user: {email} (already exists in Cognito)")
        return None
    except cognito_client.exceptions.UserNotFoundException:
        pass

    # Prepare Cognito user attributes
    attributes = [
        {'Name': 'email', 'Value': email},
        {'Name': 'name', 'Value': user_data["name"]},
        {'Name': 'custom:role', 'Value': user_data["role"]},
        {'Name': 'custom:skills', 'Value': user_data.get("skills", "")},
        {'Name': 'custom:job_type', 'Value': user_data.get("job_type", "")},
        {'Name': 'custom:experience_level', 'Value': str(map_experience_level(user_data.get("experience_level", "")))},
        {'Name': 'custom:specialization', 'Value': user_data.get("specialization", "")},
        {'Name': 'custom:company_name', 'Value': user_data.get("company_name", "")}
    ]

    # Create user in Cognito
    try:
        response = cognito_client.admin_create_user(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=email,
            UserAttributes=attributes,
            TemporaryPassword=password,
            MessageAction='SUPPRESS'
        )
        user_sub = next(attr['Value'] for attr in response['User']['Attributes'] if attr['Name'] == 'sub')
        print(f"Created Cognito user: {email} with sub: {user_sub}")

        # Set permanent password (this confirms the user)
        cognito_client.admin_set_user_password(
            UserPoolId=COGNITO_USER_POOL_ID,
            Username=email,
            Password=password,
            Permanent=True
        )
        print(f"Set permanent password for Cognito user: {email}")
    except Exception as e:
        print(f"Failed to register user in Cognito {email}: {e}")
        # Clean up: Delete user from Cognito
        try:
            cognito_client.admin_delete_user(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=email
            )
            print(f"Deleted Cognito user {email} after creation failure")
        except Exception as delete_error:
            print(f"Failed to delete Cognito user {email} after error: {delete_error}")
        return None

    # Insert user in MongoDB
    mongo_user = {
        "_id": user_data["_id"],
        "cognito_user_id": user_sub,
        "name": user_data["name"],
        "email": email,
        "role": user_data["role"],
        "company_name": user_data.get("company_name"),
        "skills": user_data.get("skills"),
        "experience_level": map_experience_level(user_data.get("experience_level")),
        "job_type": user_data.get("job_type"),
        "specialization": user_data.get("specialization"),
        "location": user_data["location"],
        "created_at": user_data["created_at"],
        "saved_jobs": [] if user_data["role"] == "job_seeker" else None
    }
    try:
        users_collection.insert_one(mongo_user)
        print(f"Inserted user in MongoDB: {email}")
        return user_sub
    except Exception as e:
        print(f"Failed to insert user in MongoDB {email}: {e}")
        # Clean up: Delete user from Cognito
        try:
            cognito_client.admin_delete_user(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=email
            )
            print(f"Deleted Cognito user {email} after MongoDB failure")
        except Exception as delete_error:
            print(f"Failed to delete Cognito user {email} after MongoDB error: {delete_error}")
        return None

# Map experience level to integer
def map_experience_level(level):
    experience_level_map = {
        "Entry-Level": 1,
        "Mid-Level": 3,
        "Senior": 5
    }
    return experience_level_map.get(level, 1)

# Sample data with unique email suffix
job_posters = [
    {
        "_id": ObjectId(),
        "name": "Ahmed Mostafa",
        "email": "ahmed.mostafa_2026hyrup@techwave.com",
        "role": "job_poster",
        "company_name": "TechWave Solutions",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Fatima Zaki",
        "email": "fatima.zaki_2026hyrup@adspark.com",
        "role": "job_poster",
        "company_name": "AdSpark Agency",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Mahmoud Rashed",
        "email": "mahmoud.rashed_2026hyrup@freightflow.com",
        "role": "job_poster",
        "company_name": "FreightFlow Logistics",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Nourhan Sami",
        "email": "nourhan.sami_2026hyrup@fintechpro.com",
        "role": "job_poster",
        "company_name": "FinTechPro",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Hassan Tarek",
        "email": "hassan.tarek_2026hyrup@healthplus.com",
        "role": "job_poster",
        "company_name": "HealthPlus Centers",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Aya Khaled",
        "email": "aya.khaled_2026hyrup@edutech.com",
        "role": "job_poster",
        "company_name": "EduTech Platform",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Ibrahim Fathy",
        "email": "ibrahim.fathy_2026hyrup@constructco.com",
        "role": "job_poster",
        "company_name": "ConstructCo Egypt",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Sara Adel",
        "email": "sara.adel_2026hyrup@marketmart.com",
        "role": "job_poster",
        "company_name": "MarketMart Retail",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Omar Youssef",
        "email": "omar.youssef_2026hyrup@agritech.com",
        "role": "job_poster",
        "company_name": "AgriTech Innovations",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Laila Ehab",
        "email": "laila.ehab_2026hyrup@consultpro.com",
        "role": "job_poster",
        "company_name": "ConsultPro Advisors",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    }
]

job_seekers = [
    {
        "_id": ObjectId(),
        "name": "Mariam Nabil",
        "email": "mariam.nabil_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Python, Django, SQL",
        "experience_level": "Mid-Level",
        "job_type": "Full-Time",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Khaled Omar",
        "email": "khaled.omar_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Data Analysis , Python , Database (SQL)",
        "experience_level": "Entry-Level",
        "job_type": "Full-Time",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Rana Hany",
        "email": "rana.hany_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Supply Chain, Inventory Control",
        "experience_level": "Mid-Level",
        "job_type": "Full-Time",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Tamer Magdy",
        "email": "tamer.magdy_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Budget Analysis, Tax Planning",
        "experience_level": "Senior",
        "job_type": "Hybrid",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Nadia Sherif",
        "email": "nadia.sherif_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Nursing, Clinical Support",
        "experience_level": "Mid-Level",
        "job_type": "Full-Time",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Amr Hesham",
        "email": "amr.hesham_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Curriculum Development, LMS",
        "experience_level": "Senior",
        "job_type": "Remote",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Dina Rami",
        "email": "dina.rami_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Civil Engineering, Revit",
        "experience_level": "Mid-Level",
        "job_type": "Full-Time",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Youssef Ali",
        "email": "youssef.ali_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Customer Service, Sales",
        "experience_level": "Entry-Level",
        "job_type": "Part-Time",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Hana Ezz",
        "email": "hana.ezz_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Soil Science, GIS",
        "experience_level": "Mid-Level",
        "job_type": "Hybrid",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
  
    {
        "_id": ObjectId(),
        "name": "Zainab Karim",
        "email": "zainab.karim_2026hyrup@gmail.com",
        "role": "job_seeker",
        "skills": "Business Intelligence, Tableau",
        "experience_level": "Senior",
        "job_type": "Remote",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    }
]

mentors = [
    {
        "_id": ObjectId(),
        "name": "Dr. Rami Salem",
        "email": "rami.salem_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Backend Development, Python, Django",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Eng. Salma Nour",
        "email": "salma.nour_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Data Analysis , Business Analysis , Data Science ",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Prof. Adel Zaki",
        "email": "adel.zaki_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Logistics Management",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Dr. Mona Fady",
        "email": "mona.fady_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Blockchain, Financial Systems",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Hany Tamer",
        "email": "hany.tamer_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Public Health, Epidemiology",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Eng. Laila Sami",
        "email": "laila.sami_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Educational Technology",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Dr. Karim Hesham",
        "email": "karim.hesham_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Architecture, BIM",
        "location": "Giza, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Nermine Adel",
        "email": "nermine.adel_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Retail Strategy, E-commerce",
        "location": "Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Prof. Ehab Nour",
        "email": "ehab.nour_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Precision Agriculture",
        "location": "New Cairo, Egypt",
        "created_at": datetime.now()
    },
    {
        "_id": ObjectId(),
        "name": "Dr. Aya Mahmoud",
        "email": "aya.mahmoud_2026hyrup@mentor.com",
        "role": "mentor",
        "specialization": "Data Science, Strategy",
        "location": "Alexandria, Egypt",
        "created_at": datetime.now()
    }
]

jobs = [
    {
        "_id": ObjectId(),
        "job_title": "Backend Developer",
        "company_name": "TechWave Solutions",
        "location": "Cairo, Egypt",
        "job_type": "Full-Time",
        "category": "general",
        "description": "Develop APIs and manage databases using Python and Django.",
        "contact_email": "hr@techwave.com",
        "deadline": datetime.now() + timedelta(days=30),
        "created_at": datetime.now(),
        "posted_by": job_posters[0]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Content Marketing Specialist",
        "company_name": "AdSpark Agency",
        "location": "Alexandria, Egypt",
        "job_type": "Remote",
        "category": "juniors",
        "description": "Create SEO-optimized content and manage campaigns.",
        "contact_email": "jobs@adspark.com",
        "deadline": datetime.now() + timedelta(days=45),
        "created_at": datetime.now(),
        "posted_by": job_posters[1]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Logistics Coordinator",
        "company_name": "FreightFlow Logistics",
        "location": "Giza, Egypt",
        "job_type": "Full-Time",
        "category": "general",
        "description": "Coordinate shipping and manage inventory systems.",
        "contact_email": "careers@freightflow.com",
        "deadline": datetime.now() + timedelta(days=20),
        "created_at": datetime.now(),
        "posted_by": job_posters[2]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Financial Analyst",
        "company_name": "FinTechPro",
        "location": "New Cairo, Egypt",
        "job_type": "Hybrid",
        "category": "general",
        "description": "Analyze financial data and support platform growth.",
        "contact_email": "hr@fintechpro.com",
        "deadline": datetime.now() + timedelta(days=60),
        "created_at": datetime.now(),
        "posted_by": job_posters[3]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Nurse Practitioner",
        "company_name": "HealthPlus Centers",
        "location": "Cairo, Egypt",
        "job_type": "Full-Time",
        "category": "general",
        "description": "Provide patient care and support medical staff.",
        "contact_email": "jobs@healthplus.com",
        "deadline": datetime.now() + timedelta(days=30),
        "created_at": datetime.now(),
        "posted_by": job_posters[4]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Instructional Designer",
        "company_name": "EduTech Platform",
        "location": "Alexandria, Egypt",
        "job_type": "Remote",
        "category": "juniors",
        "description": "Develop online courses and manage LMS content.",
        "contact_email": "careers@edutech.com",
        "deadline": datetime.now() + timedelta(days=45),
        "created_at": datetime.now(),
        "posted_by": job_posters[5]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Civil Engineer",
        "company_name": "ConstructCo Egypt",
        "location": "Giza, Egypt",
        "job_type": "Full-Time",
        "category": "general",
        "description": "Design infrastructure projects using Revit.",
        "contact_email": "hr@constructco.com",
        "deadline": datetime.now() + timedelta(days=25),
        "created_at": datetime.now(),
        "posted_by": job_posters[6]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Retail Sales Associate",
        "company_name": "MarketMart Retail",
        "location": "Cairo, Egypt",
        "job_type": "Part-Time",
        "category": "juniors",
        "description": "Assist customers and manage store inventory.",
        "contact_email": "jobs@marketmart.com",
        "deadline": datetime.now() + timedelta(days=15),
        "created_at": datetime.now(),
        "posted_by": job_posters[7]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Farm Data Analyst",
        "company_name": "AgriTech Innovations",
        "location": "New Cairo, Egypt",
        "job_type": "Hybrid",
        "category": "general",
        "description": "Analyze agricultural data using GIS tools.",
        "contact_email": "careers@agritech.com",
        "deadline": datetime.now() + timedelta(days=40),
        "created_at": datetime.now(),
        "posted_by": job_posters[8]["_id"],
        "application_count": 0
    },
    {
        "_id": ObjectId(),
        "job_title": "Business Consultant",
        "company_name": "ConsultPro Advisors",
        "location": "Alexandria, Egypt",
        "job_type": "Remote",
        "category": "general",
        "description": "Provide strategic insights using BI tools.",
        "contact_email": "hr@consultpro.com",
        "deadline": datetime.now() + timedelta(days=50),
        "created_at": datetime.now(),
        "posted_by": job_posters[9]["_id"],
        "application_count": 0
    }
]

# Insert users and register in Cognito
inserted_user_ids = []
default_password = "SecurePass123!"  # Meets Cognito password requirements
for user in job_posters + job_seekers + mentors:
    user_sub = register_user(user, default_password)
    if user_sub:
        inserted_user_ids.append(user["_id"])

# Insert jobs (only for successfully inserted job posters)
for job in jobs:
    if job["posted_by"] in inserted_user_ids:
        try:
            jobs_collection.insert_one(job)
            print(f"Inserted job: {job['job_title']} by {job['company_name']}")
        except Exception as e:
            print(f"Failed to insert job {job['job_title']}: {e}")
    else:
        print(f"Skipped job: {job['job_title']} (job poster not inserted)")

print("Sample data insertion completed!")
client.close()