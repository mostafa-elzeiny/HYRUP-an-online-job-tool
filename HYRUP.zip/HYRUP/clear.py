import boto3
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
COGNITO_USER_POOL_ID = os.getenv('COGNITO_USER_POOL_ID')

# Initialize Cognito client
cognito_client = boto3.client('cognito-idp', region_name=AWS_REGION)

def clear_cognito_users():
    try:
        response = cognito_client.list_users(UserPoolId=COGNITO_USER_POOL_ID)
        for user in response['Users']:
            email = user['Username']
            cognito_client.admin_delete_user(
                UserPoolId=COGNITO_USER_POOL_ID,
                Username=email
            )
            print(f"Deleted Cognito user: {email}")
        print("Cognito user cleanup completed!")
    except Exception as e:
        print(f"Failed to clear Cognito users: {e}")

if __name__ == "__main__":
    clear_cognito_users()